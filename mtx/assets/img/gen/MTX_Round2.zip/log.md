# Item art generation log

| Sheet | File | Model | Seed | Date | Notes |
|---|---|---|---|---|---|
| G1 | G1.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| G2 | G2.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| G3 | G3.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| G4 | G4.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| A1 | A1.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| T1 | T1.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| T2 | T2.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| C1 | C1.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| C2 | C2.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
| C3 | C3.png | image_gen (model identifier not exposed) | not exposed | 2026-11-26 | 1254x1254 native; 2048x2048 delivery; 9 individual PNGs |
